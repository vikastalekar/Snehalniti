// Import puppeteer from 'puppeteer'
// import $ from 'jquery'

// let page, browser

// beforeAll(async () => {
//   browser = await puppeteer.launch({
//     headless: false,
//     executablePath: './chromium/Chromium.app/Contents/MacOS/Chromium',
//     args: [ '--use-fake-ui-for-media-stream' ]
//   })
//   page = await browser.newPage()
//   await page.goto('localhost:8080')
// })

// afterAll(() => {
//   browser.close()
// })

// describe('Index Page Testing', () => {
//   it('Index init', async () => {
//     expect($('#page-index')).toBeTruthy()
//   }, 30000)
// })
